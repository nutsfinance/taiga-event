import { Router, Request, Response } from "express";
import { Keyring } from "@polkadot/keyring";
import { getUser, updateUser } from "../user/controller";

const keyring = new Keyring();

const ensureLoggedIn = (req: Request, res: Response, next: any) => {
  if (req.isAuthenticated()) {
    next();
  } else {
    res.redirect("/auth/discord");
  }
};

export const formRoutes = Router();

formRoutes.get("/", ensureLoggedIn, async (req, res) => {
  const userId = (req.session as any).passport.user;
  const user = await getUser(userId);

  res.render("form", {
    email: user!.email,
    address: user!.address,
    mandalaAddress: user!.mandalaAddress,
    username: user!.discordUsername,
  });
});

formRoutes.post("/", ensureLoggedIn, async (req, res) => {
  const userId = (req.session as any).passport.user;
  const username = req.body.username;
  const emailInput = req.body.email;
  const addressInput = req.body.address;
  const mandalaAddressInput = req.body.mandalaAddress;

  let address: string | undefined;
  let mandalaAddress: string | undefined;
  try {
    address = keyring.encodeAddress(addressInput, 8);
    mandalaAddress = keyring.encodeAddress(mandalaAddressInput, 42);

    const updateRes = await updateUser(
      userId,
      emailInput,
      address,
      mandalaAddress
    );

    if (updateRes) {
      res.redirect("/form/success");
    } else {
      res.render("form", {
        username: username,
        email: emailInput,
        address: addressInput,
        error: "Error Submitting Form",
      });
    }
  } catch (error) {
    console.error(error);
    const errorMessage = `Invalid ${!address ? "Karura" : "Mandala"} Address`;

    res.render("form", {
      username: username,
      email: emailInput,
      address: addressInput,
      mandalaAddress: mandalaAddressInput,
      error: errorMessage,
    });
  }
});

formRoutes.get("/success", ensureLoggedIn, (_req, res) => {
  res.render("success");
});
