export { authRoutes } from "./auth";
export { formRoutes } from "./form";
export { loginRoutes } from "./login";
export { profileRoutes } from "./profile";