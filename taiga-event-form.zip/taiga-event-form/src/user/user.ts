export interface User {
  address?: string;
  email?: string;
  id?: string;
  discordUsername?: string;
}